**JeeLib** is an Arduino IDE library for [JeeNodes][1] (made by [JeeLabs][2])  
and for compatible devices, with drivers for its wireless radio module,  
its "JeePort" interfaces, and a range of add-on "JeePlug" interfaces.

The home page for this library is at <http://jeelabs.net/projects/jeelib/wiki>.

License: MIT

[1]: http://jeenode.com/
[2]: http://jeelabs.org/
